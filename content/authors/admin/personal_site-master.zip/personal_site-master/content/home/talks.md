+++
# Recent and Upcoming Talks widget.
widget = "talks"
active = true
date = 2016-04-20T00:00:00

title = "Recent & Upcoming Talks"
subtitle = ""

# Order that this section will appear in.
weight = 15

# Number of talks to list.
count = 10

# List format.
#   0 = Simple
#   1 = Detailed
list_format = 0

+++

- **Graphs Galore! Representing Knowledge in the Sciences and Humanities**    
    *Carleton College. October 22, 2019.* ([Slides](https://docs.google.com/presentation/d/1gh2qpDZhjUDgV-Qo2QZrADnGxwaD2qU7k-zNSHAjvOE/edit?usp=sharing))    
    *Macalester College. November 1, 2019.* ([Slides](https://docs.google.com/presentation/d/1LQY6P4qZJnVg-s8w0wxPzSjc3-A8nWpuyh-Z5MJ9xDc/edit?usp=sharing))

